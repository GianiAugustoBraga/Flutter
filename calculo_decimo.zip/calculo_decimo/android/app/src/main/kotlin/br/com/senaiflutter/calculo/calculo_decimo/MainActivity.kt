package br.com.senaiflutter.calculo.calculo_decimo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
