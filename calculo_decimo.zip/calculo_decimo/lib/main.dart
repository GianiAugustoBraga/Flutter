import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cálculo 13º salário',
      theme: ThemeData(
        primaryColor: Colors.blue,
      ),
      home: MyHomePage(title: 'Cálculo 13º Salário'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Controllers necessários para receber os textos
  TextEditingController salarioController = TextEditingController();
  TextEditingController mesesController = TextEditingController();

  // Chave necessária para enviar o formulário
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Texto que vai aparecer no inicio do app, e modificando durante a execução
  String _info = 'Preencha as informações';

  // Função para calcular o 13º salário
  void _calcular() {
    setState(() {
      double salario = double.parse(salarioController.text);
      double meses = double.parse(mesesController.text);
      double decimo = (salario / 12) * meses;
      decimo = double.parse(decimo.toStringAsFixed(2));
      print(decimo);

      _info = 'Você irá receber R\$$decimo';
    });
  }

  //Função para resetar os campos
  void _resetFields() {
    salarioController.text = '';
    mesesController.text = '';

    setState(() {
      _info = 'Preencha as informações';
      _formKey = GlobalKey<FormState>();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        centerTitle: true,
        actions: <Widget>[
          IconButton(onPressed: _resetFields, icon: Icon(Icons.refresh)),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 40),
            //Texto da parte superior da tela
            Text(
              _info,
              style: TextStyle(
                fontSize: 20,
              ),
            ),

            // Campo para inserir valores
            Padding(
              padding: EdgeInsets.all(20),
              // Formulário para inserir os valores
              child: TextFormField(
                key: _formKey,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Informe o salário:",
                  labelStyle: TextStyle(color: Colors.grey),
                ),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.blue),
                controller: salarioController,
              ),
            ),

            // Campo para inserir valores
            Padding(
              padding: EdgeInsets.all(20),
              // Formulário para inserir os valores
              child: TextFormField(
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Informe os meses trabalhados:",
                  labelStyle: TextStyle(color: Colors.grey),
                ),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.blue),
                controller: mesesController,
              ),
            ),

            //Botão para calcular
            ElevatedButton(
              onPressed: () {
                _calcular();
              },
              child: Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}
