package com.example.contador_pessoa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
