package br.com.senaiflutter.notas.notas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
