import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Média das notas dos alunos',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Média Alunos'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _info = 'Informe as notas';

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController nota1Controller = TextEditingController();
  TextEditingController nota2Controller = TextEditingController();
  TextEditingController nota3Controller = TextEditingController();

  void _calcular() {
    setState(() {
      double nota1 = double.parse(nota1Controller.text);
      double nota2 = double.parse(nota2Controller.text);
      double nota3 = double.parse(nota3Controller.text);
      double media = (nota1 + nota2 + nota3) / 3;
      media = double.parse(media.toStringAsFixed(2));

      _info = 'Informe as notas';

      print(media);
      if (media < 3) {
        setState(() {
          _info = 'Reprovado! sua nota final é $media';
        });
      } else if (media >= 3 && media <= 6) {
        _info = 'Recuperação! sua nota final é $media';
      } else {
        _info = 'Aprovado! sua nota é $media';
      }
    });
  }

  void _resetFields() {
    nota1Controller.text = '';
    nota2Controller.text = '';
    nota3Controller.text = '';

    setState(() {
      _info = "Preencha as informações:";
      _formKey = GlobalKey<FormState>();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(widget.title),
        actions: <Widget>[
          IconButton(onPressed: () {}, icon: Icon(Icons.refresh))
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Text(_info),
            TextFormField(
              key: _formKey,
              controller: nota1Controller,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Informe a nota 1",
                hintText: 'informar a nota separada por ponto',
              ),
              keyboardType: TextInputType.number,
            ),
            TextFormField(
              keyboardType: TextInputType.number,
              controller: nota2Controller,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Informe a nota 2",
                hintText: 'informar a nota separada por ponto',
              ),
            ),
            TextFormField(
              keyboardType: TextInputType.number,
              controller: nota3Controller,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Informe a nota 3",
                hintText: 'informar a nota separada por ponto',
              ),
            ),
            ElevatedButton(
              onPressed: () {
                _calcular();
              },
              child: Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}
